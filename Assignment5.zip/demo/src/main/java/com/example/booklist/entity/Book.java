package com.example.booklist.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Book {
    @Id
	private Long bookcode;
    @Column
	private String bookname;
    @Column
	private String author;
	
	@Temporal(TemporalType.DATE)
	private Date createDate = new Date(System.currentTimeMillis());
	
		
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Book [bookcode=" + bookcode + ", bookname=" + bookname + ", author=" + author + ", createDate="
				+ createDate + "]";
	}

	public Book(Long bookcode, String bookname, String author, Date createDate) {
		super();
		this.bookcode = bookcode;
		this.bookname = bookname;
		this.author = author;
		this.createDate = createDate;
	}

	public Long getBookcode() {
		return bookcode;
	}
	public void setBookcode(Long bookcode) {
		this.bookcode = bookcode;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}
