package com.example.booklist.controller;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.booklist.entity.Book;
import com.example.booklist.repository.UserRepo;
import com.example.booklist.service.BookService;

@Controller
public class BookController {
    
	
	public BookController(BookService bookService) {
		super();
		this.bookService = bookService;
		
	}
	
	
	
	@Autowired
	private UserRepo repo;
	@Autowired
	private BookService bookService;
	
	
	
	@GetMapping("/")
	public String home() {
		return "login";
	}
	
	@PostMapping("/userlogin")
	public String loginUser(@ModelAttribute("user") User user) {
		
		String userId = user.getUsername();
//		User userdata = repo.findById(userId);
		User userdata = repo.findById(userId);
		if(user.getPassword().equals(userdata.getPassword())) {
			
			return "books";
		}
		else {
			return "login";
		}
	}
	
	
	//handeler method to handle list student and return model and view
	@GetMapping("/books")
	public String listBooks(Model model) {
		model.addAttribute("books",bookService.getAllBooks());
		return "books";
	}
	
	@GetMapping("/books/new")
	public String createBookForm(Model model) {
		
		Book book = new Book();
		
		model.addAttribute("book", book);
		return "create_book";
		
	}
	@PostMapping("/books")
	public String saveBook(@ModelAttribute("book") Book book) {
		bookService.saveBook(book);
		return "redirect:/books";
	}
	
}
