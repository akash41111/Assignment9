package com.example.booklist.service.impl;
import java.util.List;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicBean1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.booklist.entity.Book;
import com.example.booklist.repository.BookRepository;
import com.example.booklist.service.BookService;
@Service
public class BookServiceImpl implements BookService {
	
	
	@Autowired
	private BookRepository bookRepository;
	
	
	public BookServiceImpl(BookRepository bookRepository) {
		super();
		this.bookRepository = bookRepository;
	}
	
	
	
	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}
     
	@Override
	public Book saveBook(Book book) {
		return bookRepository.save(book);
	}
	
	
	
//	public Student getStudentById(Long id) {
//		return studentRepository.findById(id).get();
//	}
	@Override
	public Book getBookById(Long id) {
		return bookRepository.findById(id).get();
	}

//	@Override
//	public Student updateStudent(Student student) {
//		return studentRepository.save(student);
//	}
	@Override
	public Book updateBook(Book book) {
		return bookRepository.save(book);
	}

//	@Override
//	public void deleteStudentById(Long id) {
//		studentRepository.deleteById(id);	
//	}
	@Override
	public void deleteBookById(Long id) {
		bookRepository.deleteById(id);
	}
	
}
