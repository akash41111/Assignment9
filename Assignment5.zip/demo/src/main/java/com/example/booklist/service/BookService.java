package com.example.booklist.service;

import com.example.booklist.entity.Book;

import java.util.List;
//import java.util.list;

public interface BookService {
	List<Book> getAllBooks();

	// to save 
	// Student saveStudent(Student student);
	Book saveBook(Book book);

	Book getBookById(Long id);

	Book updateBook(Book book);

	void deleteBookById(Long id);

}
